# Algorithm Comparison Assignment

This repository contains implementation of four different classification algorithms using the Iris dataset from sklearn.

## Algorithms Included

1. **Decision Tree Classifier** (`decision_tree.py`)
2. **Support Vector Machine (SVM)** (`svm_classifier.py`)
3. **K-Nearest Neighbors (KNN)** (`knn_classifier.py`)
4. **Random Forest Classifier** (`random_forest.py`)

## Dataset

- Built-in Iris dataset from `sklearn.datasets`

## How to Run

Each `.py` file is self-contained. To run any of them, use:

```bash
python filename.py
```

Example:

```bash
python decision_tree.py
```

Each script will print the accuracy of the classifier on the test dataset.

---

Prepared with ❤️ for assignment submission.