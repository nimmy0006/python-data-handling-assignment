
# Assignment 2: Python Data Handling with Pandas and NumPy

## 📌 Objective
To demonstrate proficiency in handling and manipulating data using Python's Pandas and NumPy libraries.

## 📁 Files
- `data_handling_assignment.py`: Main Python script containing all solutions.
- `README.md`: Description and overview of the assignment.

## 📚 Concepts Covered
- **NumPy Basics**: Array creation, slicing, mathematical operations.
- **Pandas DataFrames**: Creating, inspecting, and summarizing data.
- **Data Selection**: Row/column selection and filtering.
- **Missing Value Handling**: fillna() and dropna().
- **Data Aggregation**: GroupBy and aggregation methods.
- **Merging Data**: Combining two DataFrames based on common keys.

## ⚙️ How to Run
```bash
python data_handling_assignment.py
```

Make sure you have the required libraries installed:
```bash
pip install numpy pandas
```

## 📌 Output
The script will display output for:
- NumPy array operations
- DataFrame operations
- Missing value handling
- Filtering and grouping
- Merging DataFrames

## ✅ Status
Assignment Completed ✔️
