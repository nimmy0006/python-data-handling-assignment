
import numpy as np
import pandas as pd

# NumPy Operations
print("=== NumPy Basics ===")
arr = np.array([[1, 2, 3], [4, 5, 6]])
print("Array:\n", arr)
print("Shape:", arr.shape)
print("Sliced:\n", arr[:, 1:])
print("Sum of all elements:", np.sum(arr))
print("Mean of array:", np.mean(arr))

# Create DataFrame
print("\n=== Pandas Basics ===")
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Age': [24, 27, 22, np.nan, 29],
    'Score': [85, 90, np.nan, 88, 76]
}
df = pd.DataFrame(data)
print("DataFrame:\n", df)

# Info and Description
print("\nData Info:")
print(df.info())
print("\nSummary Statistics:")
print(df.describe())

# Data Selection
print("\nSelecting Age column:")
print(df['Age'])

# Filtering
print("\nPeople with score above 80:")
print(df[df['Score'] > 80])

# Handling Missing Values
print("\nFilling missing values:")
df_filled = df.fillna({'Age': df['Age'].mean(), 'Score': df['Score'].mean()})
print(df_filled)

# Grouping (Dummy example)
print("\nGrouping Example:")
df_filled['Passed'] = df_filled['Score'] >= 80
print(df_filled.groupby('Passed')['Age'].mean())

# Merging Example
print("\nMerging Example:")
df2 = pd.DataFrame({
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Department': ['HR', 'IT', 'IT', 'Finance', 'Marketing']
})
merged_df = pd.merge(df_filled, df2, on='Name')
print(merged_df)
